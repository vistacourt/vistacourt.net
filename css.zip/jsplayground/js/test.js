


function calculate(){
  r1 = Math.floor((Math.random() * 20) + 1);
  r2 = Math.floor((Math.random() * 20) + 1);
  r3 = Math.floor((Math.random() * 20) + 1);
  r4 = Math.floor((Math.random() * 20) + 1);
  r5 = Math.floor((Math.random() * 20) + 1);
  r6 = Math.floor((Math.random() * 20) + 1);
  r20s = Math.floor((Math.random() * 20) + 1);
  document.getElementById("c1").innerHTML = r1;
  document.getElementById("c2").innerHTML = r2;
  document.getElementById("c3").innerHTML = r3;
  document.getElementById("c4").innerHTML = r4;
  document.getElementById("c5").innerHTML = r5;
  document.getElementById("c6").innerHTML = r6;
  document.getElementById("c20s").innerHTML = r20s;
}


function randomQuote(){

  rqVar = "Test Quote";
  document.getElementById('rqId').innerHTML = rqVar;
}
